from distutils.core import setup
setup(name='commonregex',
      version='1.2',
      py_modules=['commonregex'])