from distutils.core import setup
setup(name='commonregex',
      version='1.5.1',
      py_modules=['commonregex'])