from distutils.core import setup
setup(name='commonregex',
      version='1.0',
      py_modules=['commonregex'])