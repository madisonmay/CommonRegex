from distutils.core import setup
setup(name='commonregex',
      version='1.5.5',
      py_modules=['commonregex'])